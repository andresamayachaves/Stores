import java.time.LocalDate; // Import the DateTimeFormatter class

/*
Class that represent a person.
@author Andrés Amaya Chaves
*/
public class Person {
    String name;
    String lastname1;
    String lastname2;
    LocalDate dateBirth;
    Float height;

    // Constructor.
    public Person() {
        name = "n";
        lastname1 = "n";
        lastname2 = "n";
        dateBirth = LocalDate.parse("1900-01-01");

        height = 0.0f;
    }

    // Constructor 2.
    public Person(String name_in, String lastname1_in, String lastname2_in, LocalDate dateBirth_in, Float height_in) {
        this.name = name_in;
        this.lastname1 = lastname1_in;
        this.lastname2 = lastname2_in;
        this.dateBirth = dateBirth_in;
        this.height = height_in;
    }

    /*
     * Change the name of the person.
     * 
     * @param name. Name of the color to add.
     */
    public void setName(String name_in) {
        name = name_in;
    }

    /*
     * Obtain the name of the person.
     */
    public String getName() {
        return name;
    }

}