import java.util.*;

// Represent a Fruit in the Store
public class Fruit {
    String name;
    private Float averageWeight;
    ArrayList<String> colors = new ArrayList<String>();

    // Constructor
    public Fruit() {
        name = "nn";
        averageWeight = 0.0f;

    }

    /*
     * Add a color to the Array of colors of the fruit.
     * 
     * @param name. Name of the color to add.
     */
    public void setColor(String name) {
        if (colors.contains(name) != true) {
            colors.add(name);
        } else {
            System.out.println("The fruit already has that color");
        }
    }

    /*
     * Obtain the of colors of the fruit.
     * 
     * @return colors. Array of colors of the fruit.
     */
    public ArrayList<String> getColors() {
        return colors;
    }

    /*
     * Obtain the average weight of the fruit.
     * 
     * @return averageWaight. Asverage weight of the fruit.
     */
    public Float getAverageWeight() {
        return averageWeight;
    }

}