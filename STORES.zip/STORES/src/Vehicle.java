/*
Class that represent a vehivle of the store
@author Andrés Amaya Chaves
*/
public class Vehicle {
    String Plate;
    Integer Capacity;
    String Size;

    // Constructor
    public Vehicle() {
        Plate = "None";
        Capacity = 0;
        Size = "Small";
    }

    /*
     * Obtain the plate of the vehicle.
     * 
     * @return Plate. Vehivle plate.
     */
    protected String getPlate() {
        return Plate;
    }

    /*
     * Obtain the capacity of the vehicle,. in kg.
     * 
     * @return Activated.
     */
    private Integer getCapacity() {
        return Capacity;
    }

    /*
     * Obtain the size of the vehicle.
     * 
     * @return Size. Size of the vehicle.
     */
    private String getSize() {
        return Size;
    }

    /*
     * Change the plate of the vehicle.
     * 
     * @param Plate_In. New String to assign to the Plate Attribute
     */
    private void setPlate(String Plate_In) {
        Plate = Plate_In;
    }

    /*
     * Change the Capacity of the vehicle.
     * 
     * @param Capacity_In. New String to assign to the Capacity Attribute
     */
    private void setCapacity(Integer Capacity_In) {
        Capacity = Capacity_In;
    }

    /*
     * Change the Size of the vehicle.
     * 
     * @param Capacity_In. New String to assign to the Capacity Attribute
     */
    private void setSize(String Size_In) {
        Size = Size_In;
    }

    /*
     * Change any of the attributes.
     * 
     * @param getty. String that mean which attribute to get.
     * 
     * @param info. String that assign the new value to attribute.
     */
    public String get(String getty) {
        String answer = "";
        switch (getty) {
            case "P":
                answer = getPlate();
                break;
            case "Cap":
                answer = Integer.toString(getCapacity());
                break;
            case "S":
                answer = getSize();
                break;
        }
        return answer;

    }

    /*
     * Change any of the attributes.
     * 
     * @param getty. String that mean which attribute to get.
     * 
     * @param info. String that assign the new value to attribute.
     */
    public void set(String setty, String Info) {
        switch (setty) {
            case "P":
                setPlate(Info);
                break;
            case "C":
                Integer cap = Integer.parseInt(Info);
                setCapacity(cap);
                break;
            case "S":
                setSize(Info);
                break;
        }
    }

}
