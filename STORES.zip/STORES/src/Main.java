
/*
Main class that executes the whole program
@author Andrés Amaya Chaves
*/
class Main {
    public static void main(String[] args) {

        System.out.println("");

        Person p1;
        p1 = new Person();
        p1.setName("Carlos");
        System.out.println(p1.getName());

        Fruit f = new Fruit();
        f.setColor("Blue");
        System.out.println(f.getColors());

        Vehicle v;
        v = new Vehicle();
        System.out.println(v.getPlate());
        System.out.println(v.get("Cap"));
        System.out.println(v.get("S"));

        v.set("P", "KJH304");
        v.set("C", "2400");
        v.set("S", "Medium");
        System.out.println(v.getPlate());
        System.out.println(v.get("Cap"));
        System.out.println(v.get("S"));
    }
}