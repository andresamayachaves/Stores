/*
Class that represent a product
@author Andrés Amaya Chaves
*/
public class Product {
    String Type;
    int ID;

    // Constructor
    public Product() {
        Type = "None";
        ID = 0;
    }

    /*
     * Obtain the type of product.
     * 
     * @return Type. Type of product.
     */
    public String getType() {
        return Type;
    }

    /*
     * Obtain the product ID.
     * 
     * @return ID. ID of product.
     */
    protected int getID() {
        return ID;
    }

    /*
     * Change the type of product.
     */
    private void setType(String Type_In) {
        Type = Type_In;
    }

    /*
     * Change the product ID.
     */
    private void setID(Integer ID_In) {
        ID = ID_In;
    }

    /*
     * Obtain any of the attributes.
     * 
     * @param getty. String that mean which attribute to get.
     */
    public String get(String getty) {
        String ans = "";
        switch (getty) {
            case "T":
                ans = getType();
            case "ID":
                ans = Integer.toString(getID());
        }
        return ans;
    }

    /*
     * Change any of the attributes.
     * 
     * @param getty. String that mean which attribute to get.
     * 
     * @param info. String that assign the new value to attribute.
     */
    public void set(String getty, String Info) {
        switch (getty) {
            case "P":
                setType(Info);
                break;
            case "ID":
                Integer cap = Integer.parseInt(Info);
                setID(cap);
                break;
        }
    }
}