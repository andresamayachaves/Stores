/*
Class that represent a Store of the Enterprise
@author Andrés Amaya Chaves
*/
public class Store {

    // Represent the characteristics of each Store
    Integer StoreID;
    String StoreType;
    Double FacilityArea;
    String City;
    String Zone;

    // Constructor
    public Store() {
        StoreID = 0;
        StoreType = "None";
        FacilityArea = 0.0;
        City = "None";
        Zone = "None";
    }

    // Obtains the Store ID
    protected Integer getStoreID() {
        return StoreID;
    }

    // Obtains the Store Type
    public String getStoreType() {
        return StoreType;
    }

    // Obtains the area of the facility building
    public Double getFacilityArea() {
        return FacilityArea;
    }

    // Obtains the City in which the Store is
    public String getCity() {
        return City;
    }

    // Obtains the zone of the city in wich the store is
    public String getZone() {
        return Zone;
    }

    // Change the Store ID
    private void setStoreID(Integer StoreID_In) {
        StoreID = StoreID_In;
    }

    // Change the Store Type
    private void setStoreType(String StoreType_In) {
        StoreType = StoreType_In;
    }

    // Change the area of the facility building
    private void setFacilityArea(Double FacilityArea_In) {
        FacilityArea = FacilityArea_In;
    }

    // Change the City in which the Store is
    private void setCity(String City_In) {
        City = City_In;
    }

    // Change the zone of the city in wich the store is
    private void setZone(String Zone_In) {
        Zone = Zone_In;
    }

    // Set any of the attributes
    public void set(String setty, String Info) {
        switch (setty) {
            case "ID":
                setStoreID(Integer.parseInt(Info));
            case "ST":
                setStoreType(Info);
            case "A":
                setFacilityArea(Double.parseDouble(Info));
            case "C":
                setCity(Info);
            case "Z":
                setZone(Info);
        }
    }
}