/*
Class that represent  Bankaccount 
@author Andrés Amaya Chaves
*/
public class BankAccount {
    private Integer AccountNumber;
    protected Boolean Activated;

    // Constructor
    BankAccount() {
        AccountNumber = 0;
        Activated = false;
    }

    /*
     * Obtain the status of Activation of the Account.
     * 
     * @return Activated.
     */
    public Boolean getActived() {
        return Activated;
    }

    /*
     * Obtain the status of Activation of the Account.
     * 
     * @return Activated.
     */
    public Integer getAcNumber() {
        return AccountNumber;
    }

    /*
     * Change the status of Activation of the Account.
     * 
     * @param Activated_In. New status of activation
     */
    public void setActived(Boolean Actived_In) {
        Activated = Actived_In;
    }

}